<?php
/*
* Plugin Name: WooHorizont
* Plugin URI: http://elvirainfotech.com/
* Description: Allow moderator to go thorugh pages quickly.
* Author: Raihan Reza
* Author URI: http://webtaxonomy.com/
* Version: 1.0.0
* Requires at least: 1.0
* Tested up to: 4.8
* Text Domain: horizont-woocommerce
*
* Copyright (c) 2018 Elvira Infotech
*
*/
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if (!class_exists('WooHorizont')) {
	class WooHorizont {
		function __construct() {
			/*if ( ! class_exists( 'WooCommerce' ) ) {
			return;
			}*/
			
			add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'plugin_action_links' ) );
			add_action( 'woocommerce_order_status_processing', array(&$this,'action_woocommerce_order_status_processing'), 10, 1 );
			add_action('wp', array( $this, 'wxc_activation' ));
			add_filter( 'cron_schedules', array( $this, 'horizont_add_every_thirty_minutes' ) );
			add_action( 'horizont_add_every_thirty_minutes', array( $this, 'every_thirty_minutes_event_func' ) );
			register_deactivation_hook(__FILE__, array( $this, 'wh_deactivation' ));
			
		}
		function horizont_add_every_thirty_minutes( $schedules ) {
		$schedules['every_thirty_minutes'] = array(
		'interval'  => 1800,
		'display'   => __( 'Every 30 Minutes', 'textdomain' )
		);
		return $schedules;
		}
		function every_thirty_minutes_event_func() {
		// do something
		$this->stock_update();
		}
		function wxc_activation() {
		if ( ! wp_next_scheduled( 'horizont_add_every_thirty_minutes' ) ) {
		wp_schedule_event( time(), 'every_thirty_minutes', 'horizont_add_every_thirty_minutes' );
		}
		}
		function get_product_by_sku( $sku ) {
		global $wpdb;
		$product_id = $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM $wpdb->postmeta WHERE meta_key='_sku' AND meta_value='%s' LIMIT 1", $sku ) );
		if ( $product_id ) return $product_id;
		return null;
		}
		function stock_update(){
					$auth = 'd2Vic2hvcHVzZXI6aG9yaTNvTlQ0MVVsaQ==';
			//$submit_url = 'http://52.174.187.241/horizontWebShopAPI/companies';
			//$submit_url='http://52.174.187.241/horizontWebShopAPI/Help/Api/GET-companies'
$submit_url ='http://52.174.187.241/horizontWebShopAPI/products/product_codes_codes[0]';
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $submit_url);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json',
			'Authorization: Basic '.$auth));
			curl_setopt($ch, CURLOPT_USERAGENT, 'PHP-MCAPI/2.0');
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_TIMEOUT, 30);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			$result = curl_exec($ch);
			curl_error($ch);
			curl_close ($ch);
			$data = json_decode($result);
			//print_r($data);
			foreach ($data as $key => $value) {
				$quantity = $value->Quantity;
				$pr_id = $this->get_product_by_sku($value->ID);
				update_post_meta( $pr_id,'_stock',$quantity );
				
			}
				
		}
		
		// define the woocommerce_order_status_processing callback
function action_woocommerce_order_status_processing($order_id)
		{
		$order = wc_get_order( $order_id );
		$order_data = $order->get_data(); // The Order data
		$order_billing_first_name = $order_data['billing']['first_name'];
		$order_billing_last_name = $order_data['billing']['last_name'];
		$order_billing_email = $order_data['billing']['email'];
		$order_billing_phone = $order_data['billing']['phone'];
		$order_billing_address_1 = $order_data['billing']['address_1'];
		$order_billing_address_2 = $order_data['billing']['address_2'];
		$order_billing_city = $order_data['billing']['city'];
		$order_billing_country = $order_data['billing']['country'];
		$order_billing_postcode = $order_data['billing']['postcode'];
		$order_date_created = $order_data['date_created']->date('Y-m-d H:i:s');
		$order_payment_method = $order_data['payment_method'];

			$input_xml='<?xml version="1.0" encoding="UTF-8"?>';
			$input_xml.='<Order xmlns="http://schemas.datacontract.org/2004/07/horizont_web_shop_API.Models" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">';
			$input_xml.='<Company_VAT_ID>ATU64422333</Company_VAT_ID>';
			$input_xml.= '<Customer>';
			$input_xml.= '<Address>'.$order_billing_address_1.' '.$order_billing_address_2.'</Address>';
			$input_xml.= '<City>'.$order_billing_city.'</City>';
			$input_xml.= '<Country>'.$order_billing_country.'</Country>';
			$input_xml.= '<Email>'.$order_billing_email.'</Email>';
			$input_xml.= '<ID>sample string 1</ID>';
			$input_xml.= '<Name>'.$order_billing_first_name.' '.$order_billing_last_name.'</Name>';
			$input_xml.= '<Phone>'.$order_billing_phone.'</Phone>';
			$input_xml.= '<VAT_ID>sample string 3</VAT_ID>';
			$input_xml.= '<Zip_Code>'.$order_billing_postcode.'</Zip_Code>';
			$input_xml.= '</Customer>';
			$input_xml.= '<Date_Time>'.$order_date_created.'</Date_Time>';
			$input_xml.= '<Number>36589</Number>';
			$input_xml.= '<Order_Items>';
			foreach ($order->get_items() as $item_key => $item_values){
			$item_name = $item_values->get_name(); // Name of the product
			$product = $item_values->get_product(); // the WC_Product object
			$item_data = $item_values->get_data();
			// Get data from The WC_product object using methods (examples)
			$product_type   = $product->get_type();
			$product_sku    = $product->get_sku();
			$product_price  = $product->get_price();
			$stock_quantity = $product->get_stock_quantity();
			$product_id = $item_data['product_id'];
			$stock_Name='';
			$stock_Location='';
			$input_xml.= '<Order_Item>';
			$input_xml.= '<Barcode>sample string 4</Barcode>';
			$input_xml.= '<ID>'.$product_id.'</ID>';
			$input_xml.= '<Quantity>'.$stock_quantity.'</Quantity>';
			$input_xml.= '<Stock_Location>'.$stock_Location.'</Stock_Location>';
			$input_xml.= '<Stock_Name>'.$stock_Name.'</Stock_Name>';
			$input_xml.= '<Description>'.$item_name.'</Description>';
			$input_xml.= '<Price>'.$product_price.'</Price>';
			$input_xml.= '</Order_Item>';
			}
			$input_xml.= '</Order_Items>';
			$input_xml.= '<Payment_ID>'.$order_payment_method.'</Payment_ID>';
			$input_xml.= '</Order>';
$url = "http://52.174.187.241/horizontWebShopAPI/order/send";
$username ="webshopuser";
$password= "hori3oNT41Uli";
//setting the curl parameters.
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
// Following line is compulsary to add as it is:
curl_setopt($ch, CURLOPT_POSTFIELDS,
"xmlRequest=" . $input_xml);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 300);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
$data = curl_exec($ch);
curl_close($ch);
}

function plugin_action_links($links){
$setting_link = $this->get_setting_link();
$plugin_links = array(
/*'<a href="' . $setting_link . '">' . __( 'Settings', 'horizont-woocommerce' ) . '</a>',*/
'<a href="http://elvirainfotech.com/contact/" target="_blank">' . __( 'Docs', 'horizont-woocommerce' ) . '</a>',
'<a href="http://webtaxonomy.com/contact/" target="_blank">' . __( 'Support', 'horizont-woocommerce' ) . '</a>',
);
return array_merge( $plugin_links, $links );
}

function get_setting_link() {
return admin_url( 'options-general.php?page=options_wh_setting' );
}
}
}
$GLOBALS['WooHorizont'] = new WooHorizont();

$input_xml='<?xml version="1.0" encoding="UTF-8"?>
<Order xmlns="http://schemas.datacontract.org/2004/07/horizont_web_shop_API.Models"xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><Company_VAT_ID> ATU64422333 </Company_VAT_ID><Customer><Address>1142 Anmoore Road New York, NY 10019</Address><City>NY</City><Country>American</Country><Email>EdwardTRiddle@rhyta.com</Email><ID>sample string 1</ID><Name>Edward T. Riddle</Name><Phone>718-807-8203</Phone><VAT_ID>sample string 3</VAT_ID>
<Zip_Code>33</Zip_Code></Customer><Date_Time>2018-07-24T08:38:36.5885754+02:00</Date_Time><Number>36589</Number><Order_Items><Order_Item><Barcode>sample string 4</Barcode><ID>9686</ID><Quantity>5</Quantity>
<Stock_Location>7</Stock_Location><Stock_Name>6</Stock_Name><Description>sample string 1</Description>
<Price>2</Price></Order_Item></Order_Items><Payment_ID>3</Payment_ID></Order>';

$url = "http://52.174.187.241/horizontWebShopAPI/order/send";
//$auth = 'd2Vic2hvcHVzZXI6aG9yaTNvTlQ0MVVsaQ==';
$username ="webshopuser";
$password= "hori3oNT41Uli";
//setting the curl parameters.
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
// Following line is compulsary to add as it is:
curl_setopt($ch, CURLOPT_POSTFIELDS,
            "xmlRequest=" . $input_xml);
curl_setopt( $ch, CURLOPT_POSTFIELDS, "$input_xml" );
//curl_setopt($ch, CURLOPT_HTTPHEADER, array('Authorization: Basic '.$auth));
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 300);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
$data = curl_exec($ch);
//$info = curl_getinfo($ch);
curl_close($ch);
//convert the XML result into array
//$array_data = json_decode(json_encode($data));
print_r($data);


